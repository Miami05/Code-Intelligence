int one_liner() { int x=1; int y=2; if(x>0){return x+y;} return 0; }

int normal() {
    int a = 1;
    int b = 2;
    if (a > 0) {
        return a + b;
    }
    return 0;
}
